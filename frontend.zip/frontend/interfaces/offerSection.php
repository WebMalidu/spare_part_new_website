<section class="offerSection p-4">
    <div class="container">
        <div class="col-12">
            <h3 class=" alg-text-blue mt-3 mb-4 fw-bold fs-2">Offer Section</h3>
            <div class="swiper mySwiperk">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>

                    </div>
                    <div class="swiper-slide">
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                        <div>
                            <img src="resources/image/offer.png" class="alg-slider-img" alt="">
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>
</section>