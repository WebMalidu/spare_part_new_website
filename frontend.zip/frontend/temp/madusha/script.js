// swiper animation
var swiper = new Swiper(".mySwiperld", {
     direction: "vertical",
     pagination: {
       el: ".swiper-pagination",
       clickable: true,
     },
   });